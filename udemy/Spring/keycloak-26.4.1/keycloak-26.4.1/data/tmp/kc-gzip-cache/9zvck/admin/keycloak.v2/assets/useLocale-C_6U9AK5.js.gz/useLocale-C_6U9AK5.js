import{useMemo as o}from"react";import{d as a,ek as s}from"./main-Dv0zjgcK.js";function u(){const{realmRepresentation:e}=a(),t=o(()=>e?.supportedLocales?.length?e.supportedLocales:[s],[e]),r=o(()=>e?.defaultLocale?.length?[e.defaultLocale]:[],[e]);return o(()=>Array.from(new Set([...r,...t])),[r,t])}export{u};
//# sourceMappingURL=useLocale-C_6U9AK5.js.map
