import{du as e,cO as d,dv as f,dw as h}from"./main-Dv0zjgcK.js";var o=e?e.isConcatSpreadable:void 0;function m(n){return d(n)||f(n)||!!(o&&n&&n[o])}function y(n,g,i,r,a){var t=-1,b=n.length;for(i||(i=m),a||(a=[]);++t<b;){var s=n[t];i(s)?h(a,s):r||(a[a.length]=s)}return a}export{y as b};
//# sourceMappingURL=_baseFlatten-aMIXDFBU.js.map
