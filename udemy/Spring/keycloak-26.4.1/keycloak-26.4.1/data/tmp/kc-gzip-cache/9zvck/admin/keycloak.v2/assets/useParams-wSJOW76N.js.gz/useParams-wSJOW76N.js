import{c as s}from"./main-Dv0zjgcK.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-wSJOW76N.js.map
