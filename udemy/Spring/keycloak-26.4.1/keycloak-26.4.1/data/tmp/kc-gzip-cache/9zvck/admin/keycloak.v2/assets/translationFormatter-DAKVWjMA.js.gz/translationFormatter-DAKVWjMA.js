import{cg as o}from"./main-Dv0zjgcK.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-DAKVWjMA.js.map
