import{jsx as e}from"react/jsx-runtime";import{F as s}from"./FileUploadForm-CUrN37kc.js";const t=({onChange:n,...o})=>e(s,{...o,language:"json",extension:".json",onChange:a=>{try{n(JSON.parse(a))}catch{n({}),console.warn("Invalid json, ignoring value using {}")}}});export{t as J};
//# sourceMappingURL=JsonFileUpload-Bp1fGics.js.map
