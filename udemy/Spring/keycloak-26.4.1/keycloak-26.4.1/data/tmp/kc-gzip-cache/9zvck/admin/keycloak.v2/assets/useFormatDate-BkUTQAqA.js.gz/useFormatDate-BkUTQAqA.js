import{cX as r}from"./main-Dv0zjgcK.js";const s={dateStyle:"long",timeStyle:"short"};function c(){const{whoAmI:t}=r();return function(o,e){return o.toLocaleString(t.locale,e)}}export{s as F,c as u};
//# sourceMappingURL=useFormatDate-BkUTQAqA.js.map
