import{cX as l}from"./main-Dv0zjgcK.js";function i(){const{whoAmI:o}=l();return function(n,r){return[...n].sort((a,s)=>{const e=r(a),c=r(s);return e===void 0||c===void 0?0:e.localeCompare(c,o.locale)})}}const m=o=>t=>t[o];export{m,i as u};
//# sourceMappingURL=useLocaleSort-CYT_eE_Q.js.map
